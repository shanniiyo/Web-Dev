jest.mock("../models/Reservation");
jest.mock("../models/Flight");
jest.mock("../utils/auditLogger", () => ({
  logActivity: jest.fn(),
}));

const Reservation = require("../models/Reservation");
const Flight = require("../models/Flight");
const reservationController = require("../controllers/reservationController");

describe("Reservation Management Unit Tests", () => {
  let req;
  let res;

  beforeEach(() => {
    req = {
      body: {
        flightId: "flight123",
        passengerName: "shan dipatuan",
        email: "shan@test.com",
        passportNumber: "P12323456",
        seatNumber: "3A",
      },

      params: {
        id: "reservation123",
      },

      session: {
        user: {
          email: "user@test.com",
          role: "passenger",
        },
      },
    };

    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
      redirect: jest.fn(),
    };

    jest.clearAllMocks();
  });

  // ==================================
  // CREATE RESERVATION
  // ==================================

  test("Create Reservation", async () => {
    const flight = {
      _id: "flight123",
      flightNumber: "PR100",
      ticketPrice: 2500,
      availableSeats: 5,
      seats: [
        {
          seatNumber: "3A",
          isAvailable: true,
        },
      ],
      save: jest.fn().mockResolvedValue(true),
    };

    Flight.findById = jest.fn().mockResolvedValue(flight);

    Reservation.findOne = jest.fn().mockResolvedValue(null);

    Reservation.mockImplementation(function (data) {
      return {
        ...data,
        save: jest.fn().mockResolvedValue(true),
      };
    });

    await reservationController.createReservation(req, res);

    expect(Flight.findById).toHaveBeenCalledWith("flight123");

    expect(Reservation.findOne).toHaveBeenCalled();

    expect(res.status).toHaveBeenCalledWith(201);
  });

  // ==================================
  // CANCEL RESERVATION
  // ==================================

  test("Cancel Reservation", async () => {
    const reservation = {
      _id: "reservation123",
      reservationNumber: "BR-100001",
      bookingStatus: "Confirmed",
      seatNumber: "1A",
      flight: "flight123",

      save: jest.fn().mockResolvedValue(true),
    };

    Reservation.findById = jest.fn().mockResolvedValue(reservation);

    Flight.findByIdAndUpdate = jest.fn().mockResolvedValue(true);

    await reservationController.cancelReservation(req, res);

    expect(Reservation.findById).toHaveBeenCalledWith("reservation123");

    expect(reservation.save).toHaveBeenCalled();

    expect(Flight.findByIdAndUpdate).toHaveBeenCalled();

    expect(res.json).toHaveBeenCalledWith({
      success: true,
      reservation,
    });
  });
});
