jest.mock("../models/Flight");
jest.mock("../models/Reservation");
jest.mock("../utils/auditLogger", () => ({
  logActivity: jest.fn(),
}));

const Flight = require("../models/Flight");
const Reservation = require("../models/Reservation");
const reservationController = require("../controllers/reservationController");

describe("Seat Selection Tests", () => {
  let req;
  let res;

  beforeEach(() => {
    req = {
      body: {
        flightId: "flight123",
        passengerName: "Juan Dela Cruz",
        email: "juan@test.com",
        passportNumber: "P12345678",
        seatNumber: "1A",
      },
      session: {
        user: {
          email: "user@test.com",
          role: "passenger",
        },
      },
    };

    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    jest.clearAllMocks();
  });

  test("Selecting an occupied seat", async () => {
    const flight = {
      _id: "flight123",
      flightNumber: "PR100",
      availableSeats: 5,
      ticketPrice: 2500,
      seats: [
        {
          seatNumber: "1A",
          isAvailable: false,
        },
      ],
    };

    Flight.findById = jest.fn().mockResolvedValue(flight);

    Reservation.findOne = jest.fn().mockResolvedValue({
      seatNumber: "1A",
      bookingStatus: "Confirmed",
    });

    await reservationController.createReservation(req, res);

    expect(Flight.findById).toHaveBeenCalledWith("flight123");
    expect(Reservation.findOne).toHaveBeenCalled();

    expect(res.status).toHaveBeenCalledWith(400);

    expect(res.json).toHaveBeenCalledWith({
      error: "This seat is already taken",
    });
  });
});
