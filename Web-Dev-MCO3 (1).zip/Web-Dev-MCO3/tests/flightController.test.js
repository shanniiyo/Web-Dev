jest.mock("../models/Flight");
jest.mock("../utils/auditLogger", () => ({
  logActivity: jest.fn(),
}));

const Flight = require("../models/Flight");
const flightController = require("../controllers/flightController");

describe("Flight Management Unit Tests", () => {
  let req;
  let res;

  beforeEach(() => {
    req = {
      body: {
        flightNumber: "PR100",
        airline: "PAL",
        origin: "MNL",
        destination: "CEB",
        departureDateTime: new Date(),
        arrivalDateTime: new Date(),
        ticketPrice: 2500,
      },

      params: {
        id: "123",
      },

      session: {
        user: {
          email: "admin@test.com",
          role: "admin",
        },
      },
    };

    res = {
      redirect: jest.fn(),
      status: jest.fn().mockReturnThis(),
      send: jest.fn(),
    };

    jest.clearAllMocks();
  });

  // ===========================
  // CREATE FLIGHT
  // ===========================

  test("Create Flight", async () => {
    Flight.mockImplementation(function (data) {
      return {
        ...data,
        save: jest.fn().mockResolvedValue(true),
      };
    });

    await flightController.createFlight(req, res);

    expect(res.redirect).toHaveBeenCalledWith("/admin-flights");
  });

  // ===========================
  // UPDATE FLIGHT
  // ===========================

  test("Update Flight", async () => {
    Flight.findByIdAndUpdate = jest.fn().mockResolvedValue({
      flightNumber: "PR100",
    });

    await flightController.updateFlight(req, res);

    expect(Flight.findByIdAndUpdate).toHaveBeenCalled();

    expect(res.redirect).toHaveBeenCalledWith("/admin-flights");
  });

  // ===========================
  // DELETE FLIGHT
  // ===========================

  test("Delete Flight", async () => {
    Flight.findByIdAndDelete = jest.fn().mockResolvedValue({
      flightNumber: "PR100",
    });

    await flightController.deleteFlight(req, res);

    expect(Flight.findByIdAndDelete).toHaveBeenCalledWith("123");

    expect(res.redirect).toHaveBeenCalledWith("/admin-flights");
  });
});
