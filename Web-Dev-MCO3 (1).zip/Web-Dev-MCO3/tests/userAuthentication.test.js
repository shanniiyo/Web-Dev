const { hashPassword, verifyPassword } = require("../utils/password_utils");

describe("User Authentication Tests", () => {
  // Registration
  test("Hashes password during registration", async () => {
    const password = "Password123";

    const hashed = await hashPassword(password);

    expect(hashed).not.toBe(password);

    expect(hashed.length).toBeGreaterThan(20);
  });

  // Login
  test("Accepts the correct password", async () => {
    const password = "Password123";

    const hashed = await hashPassword(password);

    const result = await verifyPassword(password, hashed);

    expect(result).toBe(true);
  });

  // Wrong password
  test("Rejects an incorrect password", async () => {
    const password = "Password123";

    const hashed = await hashPassword(password);

    const result = await verifyPassword("WrongPassword", hashed);

    expect(result).toBe(false);
  });
});
